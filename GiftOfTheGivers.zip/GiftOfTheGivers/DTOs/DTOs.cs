﻿namespace GiftOfTheGivers.Api.DTOs
{
    // For user registration
    public class RegisterDto
    {
        public string Email { get; set; } = null!;
        public string Password { get; set; } = null!;

        // Optional fields
        public string? FirstName { get; set; }
        public string? LastName { get; set; }

        // Default role = Volunteer
        public string Role { get; set; } = "Volunteer";
    }

    // For login
    public class LoginDto
    {
        public string Email { get; set; } = null!;
        public string Password { get; set; } = null!;
    }

    // Response after login
    public class AuthResponseDto
    {
        public string Token { get; set; } = null!;
        public string UserId { get; set; } = null!;
        public string Email { get; set; } = null!;
        public List<string> Roles { get; set; } = new List<string>();
    }

    // For Donations (API communication only, not entity model)
    public class DonationDto
    {
        public int DonationId { get; set; }
        public string ResourceType { get; set; } = null!;
        public int Quantity { get; set; }
        public string? Unit { get; set; }
        public string? Status { get; set; }
        public DateTime DonationDate { get; set; }
    }


    public class IncidentDto
    {
        public int IncidentId { get; set; }
        public string Title { get; set; } = null!;
        public string? Description { get; set; }
        public string? Location { get; set; }
        public DateTime ReportedAt { get; set; }
    }

    public class VolunteerDto
    {
        public int VolunteerId { get; set; }
        public string? Skills { get; set; }
        public string? Availability { get; set; }
    }
}
