﻿using System;
using GiftOfTheGivers.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GiftOfTheGivers.Models
{
    public class Volunteer
    {
        public string? UserId { get; set; }  // FK to ApplicationUser.Id (optional)

        [ForeignKey(nameof(UserId))]
        public ApplicationUser? User { get; set; }

        [Key]
        public int VolunteerId { get; set; }

        [Required]
        [Display(Name = "Name")]
        public string Name { get; set; } = string.Empty;

        [Display(Name = "Skills")]
        public string? Skills { get; set; }

        [Display(Name = "Availability")]
        public string? Availability { get; set; }

        // Optional: Project assignment
        [ForeignKey(nameof(ProjectAssigned))]
        [Display(Name = "Assigned Project")]

        public int? ProjectAssignedId { get; set; } // nullable FK
        public Project? ProjectAssigned { get; set; }

    }
}
