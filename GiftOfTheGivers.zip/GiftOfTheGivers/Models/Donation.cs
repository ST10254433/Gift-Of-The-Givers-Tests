﻿using System;
using GiftOfTheGivers.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GiftOfTheGivers.Models
{
    public class Donation
    {
        [Key]
        public int DonationId { get; set; }

        public string? DonorUserId { get; set; } // FK to ApplicationUser.Id

        [ForeignKey(nameof(DonorUserId))]
        public ApplicationUser? Donor { get; set; }

        [Required]
        public string ResourceType { get; set; } = null!; // e.g., Food, Clothing

        [Range(1, int.MaxValue)]
        public int Quantity { get; set; }

        public string? Unit { get; set; } = "units";

        public DateTime DonationDate { get; set; } = DateTime.UtcNow;

        public string? Status { get; set; } = "Pending"; // Pending, Distributed

        public int? AssignedProjectId { get; set; } // optional future expansion
        public string DonorName { get; set; }
        public int Amount { get; set; }
    }
}
