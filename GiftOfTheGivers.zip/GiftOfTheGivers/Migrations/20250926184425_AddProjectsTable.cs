﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GiftOfTheGivers.Migrations
{
    /// <inheritdoc />
    public partial class AddProjectsTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "AssignedProjectId",
                table: "Volunteers",
                newName: "ProjectAssignedId");

            migrationBuilder.AddColumn<int>(
                name: "Id",
                table: "Volunteers",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "LastName",
                table: "Volunteers",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Projects",
                columns: table => new
                {
                    ProjectId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Projects", x => x.ProjectId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Volunteers_ProjectAssignedId",
                table: "Volunteers",
                column: "ProjectAssignedId");

            migrationBuilder.AddForeignKey(
                name: "FK_Volunteers_Projects_ProjectAssignedId",
                table: "Volunteers",
                column: "ProjectAssignedId",
                principalTable: "Projects",
                principalColumn: "ProjectId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Volunteers_Projects_ProjectAssignedId",
                table: "Volunteers");

            migrationBuilder.DropTable(
                name: "Projects");

            migrationBuilder.DropIndex(
                name: "IX_Volunteers_ProjectAssignedId",
                table: "Volunteers");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "Volunteers");

            migrationBuilder.DropColumn(
                name: "LastName",
                table: "Volunteers");

            migrationBuilder.RenameColumn(
                name: "ProjectAssignedId",
                table: "Volunteers",
                newName: "AssignedProjectId");
        }
    }
}
