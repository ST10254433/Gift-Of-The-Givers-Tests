﻿using GiftOfTheGivers.Api.Data;
using GiftOfTheGivers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GiftOfTheGivers.Api.Controllers
{
    [Authorize]
    public class IncidentsController : Controller
    {
        private readonly ApplicationDbContext _db;
        public IncidentsController(ApplicationDbContext db) => _db = db;

        // GET: /Incidents
        [AllowAnonymous] // let visitors view incidents
        public async Task<IActionResult> Index()
        {
            var incidents = await _db.Incidents
                .OrderByDescending(i => i.ReportedAt)
                .ToListAsync();

            return View("Index", incidents);
        }

        // GET: /Incidents/Create
        public IActionResult Create() => View("Create");

        // POST: /Incidents/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Incident incident)
        {
            if (!ModelState.IsValid) return View("Create", incident);

            incident.ReportedAt = DateTime.UtcNow;
            incident.ReportedByUserId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

            _db.Incidents.Add(incident);
            await _db.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        // GET: /Incidents/Edit/{id}
        public async Task<IActionResult> Edit(int id)
        {
            var incident = await _db.Incidents.FindAsync(id);
            if (incident == null) return NotFound();

            return View("Edit", incident);
        }

        // POST: /Incidents/Edit/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Incident incident)
        {
            if (!ModelState.IsValid) return View("Edit", incident);

            var existing = await _db.Incidents.FindAsync(id);
            if (existing == null) return NotFound();

            existing.Title = incident.Title;
            existing.Description = incident.Description;
            existing.Location = incident.Location;

            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: /Incidents/Delete/{id}
        public async Task<IActionResult> Delete(int id)
        {
            var incident = await _db.Incidents.FindAsync(id);
            if (incident == null) return NotFound();

            _db.Incidents.Remove(incident);
            await _db.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
    }
}
