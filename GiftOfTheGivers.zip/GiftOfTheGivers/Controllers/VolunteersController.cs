﻿using GiftOfTheGivers.Api.Data;
using GiftOfTheGivers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace GiftOfTheGivers.Controllers
{
    [Authorize]
    public class VolunteersController : Controller
    {
        private readonly ApplicationDbContext _db;

        public VolunteersController(ApplicationDbContext db) => _db = db;

        // GET: /Volunteers
        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            var volunteers = await _db.Volunteers
                .Include(v => v.ProjectAssigned)
                .OrderBy(v => v.Name)
                .ToListAsync();

            return View("Index", volunteers);
        }

        // GET: /Volunteers/Create
        [Authorize(Roles = "Volunteer,Admin")]
        public IActionResult Create()
        {
            ViewBag.ProjectList = new SelectList(_db.Projects, "ProjectId", "Name");
            return View();
        }

        // POST: /Volunteers/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Volunteer,Admin")]
        public async Task<IActionResult> Create(Volunteer volunteer)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.ProjectList = new SelectList(_db.Projects, "ProjectId", "Name", volunteer.ProjectAssignedId);
                return View(volunteer);
            }

            // link to current logged-in user if available
            volunteer.UserId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value ?? volunteer.UserId;

            _db.Volunteers.Add(volunteer);
            await _db.SaveChangesAsync();

            TempData["Success"] = "Volunteer created successfully!";
            return RedirectToAction(nameof(Index));
        }

        // GET: /Volunteers/Edit/{id}
        [AllowAnonymous]
        public async Task<IActionResult> Edit(int id)
        {
            var volunteer = await _db.Volunteers.FindAsync(id);
            if (volunteer == null) return NotFound();

            ViewBag.ProjectList = new SelectList(_db.Projects, "ProjectId", "Name", volunteer.ProjectAssignedId);
            return View("Edit", volunteer);
        }

        // POST: /Volunteers/Edit/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AllowAnonymous]
        public async Task<IActionResult> Edit(int id, Volunteer volunteer)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.ProjectList = new SelectList(_db.Projects, "ProjectId", "Name", volunteer.ProjectAssignedId);
                return View("Edit", volunteer);
            }

            var existing = await _db.Volunteers.FindAsync(id);
            if (existing == null) return NotFound();

            existing.Name = volunteer.Name;
            existing.Skills = volunteer.Skills;
            existing.Availability = volunteer.Availability;
            existing.ProjectAssignedId = volunteer.ProjectAssignedId;

            await _db.SaveChangesAsync();

            TempData["Info"] = "Volunteer details updated.";
            return RedirectToAction(nameof(Index));
        }

        // GET: /Volunteers/Details/{id}
        [AllowAnonymous]
        public async Task<IActionResult> Details(int id)
        {
            var volunteer = await _db.Volunteers
                .Include(v => v.ProjectAssigned)
                .FirstOrDefaultAsync(v => v.VolunteerId == id);

            if (volunteer == null) return NotFound();

            return View("Details", volunteer);
        }

        [AllowAnonymous]
        public async Task<IActionResult> Delete(int id)
        {
            var volunteer = await _db.Volunteers
                .Include(v => v.ProjectAssigned)
                .FirstOrDefaultAsync(v => v.VolunteerId == id);

            if (volunteer == null) return NotFound();

            return View("Delete", volunteer);
        }

        // POST: /Volunteers/Delete/{id}
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var volunteer = await _db.Volunteers.FindAsync(id);
            if (volunteer == null) return NotFound();

            _db.Volunteers.Remove(volunteer);
            await _db.SaveChangesAsync();

            TempData["Warning"] = "Volunteer deleted.";
            return RedirectToAction(nameof(Index));
        }
    }
}
