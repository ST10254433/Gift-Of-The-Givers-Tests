using System.Diagnostics;
using GiftOfTheGivers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GiftOfTheGivers.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        // Root / Home page
        [AllowAnonymous]
        public IActionResult Index()
        {
            return View("Index"); // Views/Home/Index.cshtml
        }

        // Privacy page
        [AllowAnonymous]
        public IActionResult Privacy()
        {
            return View("Privacy"); // Views/Home/Privacy.cshtml
        }

        // About page (optional, add a view)
        [AllowAnonymous]
        public IActionResult About()
        {
            return View("About"); // Views/Home/About.cshtml
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        [AllowAnonymous]
        public IActionResult Error()
        {
            var errorModel = new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
            };

            _logger.LogError("An error occurred. RequestId: {RequestId}", errorModel.RequestId);
            return View("Error", errorModel); // Views/Shared/Error.cshtml
        }
    }
}
